package power;

public class nomination {
    
}
