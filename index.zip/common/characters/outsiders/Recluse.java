package characters.outsiders;
import characters.CommonCharacter;
//隐士技能
public class Recluse extends CommonCharacter{

    String misread;//隐士被误认为的阵营
    public Recluse(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp,String misread) {

    }
    public void getmisreadDru(String misread)//这一步应当由说书人完成
    {
        this.misread=misread;
    }
}
