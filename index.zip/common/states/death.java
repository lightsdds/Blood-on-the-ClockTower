package states;
public class death {
    
}
