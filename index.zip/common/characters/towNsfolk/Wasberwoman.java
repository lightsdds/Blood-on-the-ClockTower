package characters.towNsfolk;
import characters.CommonCharacter;
public class Wasberwoman extends CommonCharacter{
    public Wasberwoman(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp) {

    }
}
