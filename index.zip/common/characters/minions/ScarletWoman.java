package characters.minions;
import characters.CommonCharacter;
public class ScarletWoman extends CommonCharacter{


    public ScarletWoman(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp){


    }
}
