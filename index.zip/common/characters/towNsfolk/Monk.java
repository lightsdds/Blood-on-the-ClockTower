package characters.towNsfolk;
import characters.CommonCharacter;
//僧侣技能
public class Monk extends CommonCharacter{
    public Monk(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp) {
    }
    public boolean protectionMon()//释放保护
    {
        if(healthy==true)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}
