package characters.outsiders;
import characters.CommonCharacter;
//醉鬼技能
public class Drunk extends CommonCharacter{

    String fantasy;//醉酒者以为的身份(为了防止施放技能，把酒鬼的healthy始终改为false)
    public Drunk(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp,String fantasy){
        
    }
    public void getFantasyDru(String fantasy)//这一步应当由说书人完成
    {
        this.fantasy=fantasy;
    }

}
