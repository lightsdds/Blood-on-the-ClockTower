package characters.towNsfolk;
import characters.CommonCharacter;
public class Slayer extends CommonCharacter{
    public Slayer(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp) {
    }
}
