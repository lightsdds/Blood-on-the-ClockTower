package power;

public class vote {
    
}
