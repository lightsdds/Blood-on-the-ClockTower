package characters.minions;
import characters.CommonCharacter;
public class Spy extends CommonCharacter{

    public Spy(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp){

    }
    
}
