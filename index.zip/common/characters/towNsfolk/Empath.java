package characters.towNsfolk;
import characters.CommonCharacter;
public class Empath extends CommonCharacter{
    public Empath(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp){

    }
}
