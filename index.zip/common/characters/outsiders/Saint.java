package characters.outsiders;
import characters.CommonCharacter;
public class Saint extends CommonCharacter{

    public Saint(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp){

    }
}
