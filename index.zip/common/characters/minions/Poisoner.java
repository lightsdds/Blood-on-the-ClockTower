package characters.minions;
import characters.CommonCharacter;
public class Poisoner extends CommonCharacter{


    public Poisoner(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp){


    }

    //毒师技能
    //施毒并对健康状态返回false
    public boolean poisoningPoisoner()
    {
        return true;
    }
}
