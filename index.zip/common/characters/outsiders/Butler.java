package characters.outsiders;
import characters.CommonCharacter;
import java.util.Scanner;
//管家技能选择主人（master）
//ps：你就是老子的master吗
public class Butler extends CommonCharacter{

    //对管家对象添加了master
    public int master;
    public Butler(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp,int master){
    }
    public void getMasterBut()
    {
        if(healthy==true)
        {
            //这个会回收错误
        try (Scanner s = new Scanner(System.in))
        {
            master=s.nextInt();
        }
        }
    }

}
