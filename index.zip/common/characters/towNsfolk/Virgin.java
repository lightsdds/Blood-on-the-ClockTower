package characters.towNsfolk;
import characters.CommonCharacter;
public class Virgin extends CommonCharacter{
    public Virgin(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp) {
    }
}
