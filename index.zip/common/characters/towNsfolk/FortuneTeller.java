package characters.towNsfolk;
import characters.CommonCharacter;
public class FortuneTeller extends CommonCharacter{
    public FortuneTeller(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp) {
    }
}
