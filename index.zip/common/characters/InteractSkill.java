package characters;
import characters.*;

public class InteractSkill {

    String characterNameLmp;
    String characterNameBar;
    String characterNamePoi;
    String characterNameSca;
    String characterNameSpy;
    String characterNameBut;
    String characterNameDru;
    String characterNameRec;
    String characterNameSai;
    String characterNameCbe;
    String characterNameEmp;
    String characterNameFor;
    String characterNameInv;
    String characterNameLib;
    String characterNameMay;
    String characterNameMon;
    String characterNameRav;
    String characterNameSla;
    String characterNameSol;
    String characterNameUnd;
    String characterNameVir;
    String characterNameWas;

    int idLmp;
    int idBar;
    int idPoi;
    int idSca;
    int idSpy;
    int idBut;
    int idDru;
    int idRec;
    int idSai;
    int idCbe;
    int idEmp;
    int idFor;
    int idInv;
    int idLib;
    int idMay;
    int idMon;
    int idRav;
    int idSla;
    int idSol;
    int idUnd;
    int idVir;
    int idWas;

    boolean healthyLmp;
    boolean deathLmp;
    boolean poisoningLmp;
    boolean protectionLmp;
    String occupationLmp;
    String campLmp;
    









}
