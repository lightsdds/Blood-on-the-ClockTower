package characters.towNsfolk;
import characters.CommonCharacter;
public class Mayor extends CommonCharacter{
    public Mayor(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp) {
    }
}
