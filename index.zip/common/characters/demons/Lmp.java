package characters.demons;
import characters.CommonCharacter;

public class Lmp extends CommonCharacter{

    public Lmp(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp){

    }

    //小恶魔技能
    public boolean attankerHealthy; //攻击者健康状态
    public boolean receiverProtect; //受击者保护状态
    //judgeDeathLmp判定技能是否有效，有效（对死亡状态）返回true，否则返回false
    //判定依据为攻击者健康状态，受击者保护状态
    public boolean deathLmp(boolean attankerHealthy,boolean receiverProtect)
    {   
        this.attankerHealthy=attankerHealthy;
        this.receiverProtect=receiverProtect;
        if(attankerHealthy==true&&receiverProtect==false)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
}
