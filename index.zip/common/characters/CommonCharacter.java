//所有子类角色的父类通用角色
package characters;

public class CommonCharacter {
    String characterName;//角色名称
    int id;//玩家ID
    String occupation;
    String camp;
    boolean healthy;//健康
    boolean death;//死亡
    boolean poisoning;//中毒
    boolean protection;//保护
    //构造通用角色作为父类

    public CommonCharacter(){
    }

    CommonCharacter(String characterName, int id, boolean healthy, boolean death, boolean poisoning, boolean protection,String occupation,String camp) {
        this.characterName = characterName;
        this.id = id;
        this.healthy = healthy;
        this.death = death;
        this.poisoning = poisoning;
        this.protection = protection;
    }
}

